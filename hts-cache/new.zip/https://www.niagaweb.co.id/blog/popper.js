<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="pingback" href="https://www.niagaweb.co.id/blog/xmlrpc.php">
    <meta name='robots' content='noindex, follow' />

	<!-- This site is optimized with the Yoast SEO plugin v18.2 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Niagaweb Blog</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Niagaweb Blog" />
	<meta property="og:site_name" content="Niagaweb Blog" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"Organization","@id":"https://www.niagaweb.co.id/blog/#organization","name":"Niagaweb","url":"https://www.niagaweb.co.id/blog/","sameAs":[],"logo":{"@type":"ImageObject","@id":"https://www.niagaweb.co.id/blog/#logo","inLanguage":"en-US","url":"https://www.niagaweb.co.id/blog/wp-content/uploads/2021/03/Niagaweb-Logo-01.png","contentUrl":"https://www.niagaweb.co.id/blog/wp-content/uploads/2021/03/Niagaweb-Logo-01.png","width":800,"height":195,"caption":"Niagaweb"},"image":{"@id":"https://www.niagaweb.co.id/blog/#logo"}},{"@type":"WebSite","@id":"https://www.niagaweb.co.id/blog/#website","url":"https://www.niagaweb.co.id/blog/","name":"Niagaweb Blog","description":"Info Pembuatan Website &amp; Pemasaran Online","publisher":{"@id":"https://www.niagaweb.co.id/blog/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.niagaweb.co.id/blog/?s={search_term_string}"},"query-input":"required name=search_term_string"}],"inLanguage":"en-US"}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//s.w.org' />
<link href='https://fonts.gstatic.com' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Niagaweb Blog &raquo; Feed" href="https://www.niagaweb.co.id/blog/feed/" />
<link rel="alternate" type="application/rss+xml" title="Niagaweb Blog &raquo; Comments Feed" href="https://www.niagaweb.co.id/blog/comments/feed/" />
		<script type="45aae500312a0fa76fca214f-text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/www.niagaweb.co.id\/blog\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.1"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='dashicons-css'  href='https://www.niagaweb.co.id/blog/wp-includes/css/dashicons.min.css?ver=5.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='elusive-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/vendor/codeinwp/icon-picker/css/types/elusive.min.css?ver=2.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/vendor/codeinwp/icon-picker/css/types/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='foundation-icons-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/vendor/codeinwp/icon-picker/css/types/foundation-icons.min.css?ver=3.0' type='text/css' media='all' />
<link rel='stylesheet' id='genericons-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/vendor/codeinwp/icon-picker/css/types/genericons.min.css?ver=3.4' type='text/css' media='all' />
<link rel='stylesheet' id='menu-icons-extra-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/css/extra.min.css?ver=0.12.10' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://www.niagaweb.co.id/blog/wp-includes/css/dist/block-library/style.min.css?ver=5.8.1' type='text/css' media='all' />
<style id='wp-block-library-theme-inline-css' type='text/css'>
#start-resizable-editor-section{display:none}.wp-block-audio figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-audio figcaption{color:hsla(0,0%,100%,.65)}.wp-block-code{font-family:Menlo,Consolas,monaco,monospace;color:#1e1e1e;padding:.8em 1em;border:1px solid #ddd;border-radius:4px}.wp-block-embed figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-embed figcaption{color:hsla(0,0%,100%,.65)}.blocks-gallery-caption{color:#555;font-size:13px;text-align:center}.is-dark-theme .blocks-gallery-caption{color:hsla(0,0%,100%,.65)}.wp-block-image figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-image figcaption{color:hsla(0,0%,100%,.65)}.wp-block-pullquote{border-top:4px solid;border-bottom:4px solid;margin-bottom:1.75em;color:currentColor}.wp-block-pullquote__citation,.wp-block-pullquote cite,.wp-block-pullquote footer{color:currentColor;text-transform:uppercase;font-size:.8125em;font-style:normal}.wp-block-quote{border-left:.25em solid;margin:0 0 1.75em;padding-left:1em}.wp-block-quote cite,.wp-block-quote footer{color:currentColor;font-size:.8125em;position:relative;font-style:normal}.wp-block-quote.has-text-align-right{border-left:none;border-right:.25em solid;padding-left:0;padding-right:1em}.wp-block-quote.has-text-align-center{border:none;padding-left:0}.wp-block-quote.is-large,.wp-block-quote.is-style-large{border:none}.wp-block-search .wp-block-search__label{font-weight:700}.wp-block-group.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}.wp-block-separator{border:none;border-bottom:2px solid;margin-left:auto;margin-right:auto;opacity:.4}.wp-block-separator:not(.is-style-wide):not(.is-style-dots){width:100px}.wp-block-separator.has-background:not(.is-style-dots){border-bottom:none;height:1px}.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){height:2px}.wp-block-table thead{border-bottom:3px solid}.wp-block-table tfoot{border-top:3px solid}.wp-block-table td,.wp-block-table th{padding:.5em;border:1px solid;word-break:normal}.wp-block-table figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-table figcaption{color:hsla(0,0%,100%,.65)}.wp-block-video figcaption{color:#555;font-size:13px;text-align:center}.is-dark-theme .wp-block-video figcaption{color:hsla(0,0%,100%,.65)}.wp-block-template-part.has-background{padding:1.25em 2.375em;margin-top:0;margin-bottom:0}#end-resizable-editor-section{display:none}
</style>
<link rel='stylesheet' id='edd-styles-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/easy-digital-downloads/templates/edd.min.css?ver=2.11.5' type='text/css' media='all' />
<link rel='stylesheet' id='stylesheet-dev-css'  href='https://www.niagaweb.co.id/blog/wp-content/themes/medley/assets/scss/custom/custom.css?ver=5.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='stylesheet-main-css'  href='https://www.niagaweb.co.id/blog/wp-content/themes/medley/style.css?ver=5.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/menu-icons/css/fontawesome/css/all.min.css?ver=5.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='claps-applause-css'  href='https://www.niagaweb.co.id/blog/wp-content/plugins/wp-claps-applause/css/claps-applause.css?ver=5.8.1' type='text/css' media='all' />
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-includes/js/jquery/jquery.min.js?ver=3.6.0' id='jquery-core-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<link rel="https://api.w.org/" href="https://www.niagaweb.co.id/blog/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.niagaweb.co.id/blog/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://www.niagaweb.co.id/blog/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.1" />
<meta name="generator" content="Easy Digital Downloads v2.11.5" />

<!-- Google Tag Manager -->
<script type="45aae500312a0fa76fca214f-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KPZGF6S');</script>
<!-- End Google Tag Manager -->
<script type="45aae500312a0fa76fca214f-text/javascript">
(function() {
	(function (i, s, o, g, r, a, m) {
		i['GoogleAnalyticsObject'] = r;
		i[r] = i[r] || function () {
				(i[r].q = i[r].q || []).push(arguments)
			}, i[r].l = 1 * new Date();
		a = s.createElement(o),
			m = s.getElementsByTagName(o)[0];
		a.async = 1;
		a.src = g;
		m.parentNode.insertBefore(a, m)
	})(window, document, 'script', 'https://google-analytics.com/analytics.js', 'ga');

	ga('create', 'UA-49189534-1', 'auto');
			ga('send', 'pageview');
	})();
</script>
<link rel="icon" href="https://www.niagaweb.co.id/blog/wp-content/uploads/2019/08/cropped-Niagaweb-Logo_White-Logo-Only-Gradient-Background-32x32.png" sizes="32x32" />
<link rel="icon" href="https://www.niagaweb.co.id/blog/wp-content/uploads/2019/08/cropped-Niagaweb-Logo_White-Logo-Only-Gradient-Background-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.niagaweb.co.id/blog/wp-content/uploads/2019/08/cropped-Niagaweb-Logo_White-Logo-Only-Gradient-Background-180x180.png" />
<meta name="msapplication-TileImage" content="https://www.niagaweb.co.id/blog/wp-content/uploads/2019/08/cropped-Niagaweb-Logo_White-Logo-Only-Gradient-Background-270x270.png" />
<style id="kirki-inline-styles">:root{--nav-link:rgba(0, 0, 0, 0.5);--nav-link-active:rgba(0, 0, 0, 0.7);--border-color:#dee2e6;--text-muted:rgba(0, 0, 0, 0.6);--links-color:#626ED5;--button-color:#626ED5;--body-bg-color:#ffffff;--body-color:#222425;}.progress-bar{background-color:#3adab7;}.avatar{border-color:#9ee4c7;}.wows-header-title{font-family:serif;font-size:2.1em;font-weight:700;}h1,h2,h3,h4,h5,h6,.h1,.h2,.h3,.h4,.h5,.h6, .post_content_article h1, .post_content_article h2, .post_content_article h3, .post_content_article h4, .post_content_article h5, .post_content_article h6, .sortby, .btn-view-all, .wp-block-cover__inner-container{font-family:Chivo;}body,.font-primary, figcaption, caption, .caption, .widgettitle, .wp-block-button__link, .button, .edd-cart-added-alert, .edd_download_purchase_form, cite, .pagination, table, dl, input, select, optgroup, textarea, label{font-family:Source Sans Pro;}.post_content_article, .comment-content, #comments .fn{font-family:Merriweather;font-size:1.13em;line-height:1.85;}.wows-post .post_content_article > *{margin-bottom:2rem;}/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtce9fk4LMSTfHdQ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtceFfk4LMSTc.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBmQeVVkqDOeTY.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBoQeVVkqDO.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkido18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkids18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7qsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7jsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7rsDRB9cme_xc.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7ksDRB9cme_xc.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7osDRB9cme_xc.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7psDRB9cme_xc.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7nsDRB9cme.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklyds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7jujVj9_mf.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7jujVj9_mf.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7jujVj9_mf.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67jujVj9_mf.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67jujVj9_mf.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7jujVj9_mf.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7jujVj9w.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZDf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZKf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZBf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZAf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZOf-TVrPHp.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cSZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-eCZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cyZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-ciZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-fCZKdeX3rg.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtce9fk4LMSTfHdQ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtceFfk4LMSTc.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBmQeVVkqDOeTY.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBoQeVVkqDO.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkido18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkids18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7qsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7jsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7rsDRB9cme_xc.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7ksDRB9cme_xc.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7osDRB9cme_xc.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7psDRB9cme_xc.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7nsDRB9cme.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklyds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7jujVj9_mf.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7jujVj9_mf.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7jujVj9_mf.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67jujVj9_mf.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67jujVj9_mf.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7jujVj9_mf.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7jujVj9w.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZDf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZKf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZBf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZAf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZOf-TVrPHp.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cSZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-eCZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cyZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-ciZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-fCZKdeX3rg.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteUp9gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtce9fk4LMSTfHdQ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9G4kzIxd1KFrBtceFfk4LMSTc.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteVp6gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gKHuQh39fFz2lg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9D4kzIxd1KFrBteWJ4gK_uQh39fFw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjDY_Z4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBmQeVVkqDOeTY.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9I4kzIxd1KFrBoQeVVkqDO.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjTZPZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ2sKvkQz__TF0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Chivo';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/chivo/va9F4kzIxd1KFrjrZvZ4sKvkQz__.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZYokSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkido18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkidi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZMkids18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7qsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7jsDRB9cme_xc.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7rsDRB9cme_xc.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7ksDRB9cme_xc.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7osDRB9cme_xc.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7psDRB9cme_xc.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK1dSBYKcSV-LCoeQqfX1RYOo3qPZ7nsDRB9cme.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZY4lCds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSdi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZclSds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydh18K0xR41YDw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydo18K0xR41YDw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydg18K0xR41YDw.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydv18K0xR41YDw.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydj18K0xR41YDw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklydi18K0xR41YDw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKwdSBYKcSV-LCoeQqfX1RYOo3qPZZklyds18K0xR41.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 200;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i94_wlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ik4zwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNa7jujVj9_mf.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qPK7jujVj9_mf.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNK7jujVj9_mf.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qO67jujVj9_mf.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qN67jujVj9_mf.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qNq7jujVj9_mf.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xK3dSBYKcSV-LCoeQqfX1RYOo3qOK7jujVj9w.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3i54rwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3ig4vwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmhdo3cOWxy40.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwkxdo3cOWxy40.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmxdo3cOWxy40.woff) format('woff');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmBdo3cOWxy40.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwmRdo3cOWxy40.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Source Sans Pro';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/source-sans-pro/6xKydSBYKcSV-LCoeQqfX1RYOo3iu4nwlxdo3cOWxw.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7lXff4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZDf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZKf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZBf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZAf-TVrPHpBXw.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4m0qyriQwlOrhSvowK_l5-eRZOf-TVrPHp.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR71Wvf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf1jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf8jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf3jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf2jvrDP3WGO5g.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4l0qyriQwlOrhSvowK_l5-eR7NWPf4jvrDP3WG.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l521wRZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cSZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-eCZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-cyZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-ciZKdeX3rsHo.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-440qyriQwlOrhSvowK_l5-fCZKdeX3rg.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52xwNZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVcf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZXMf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* vietnamese */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZV8f8hPvhPUWH.woff) format('woff');
  unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZVsf8hPvhPUWH.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Merriweather';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://www.niagaweb.co.id/blog/wp-content/fonts/merriweather/u-4n0qyriQwlOrhSvowK_l52_wFZWMf8hPvhPQ.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}</style></head>
<body class="error404 wp-embed-responsive wows-body">

    
    
<div class="wrap-logo-header ">

  <div class="container wows-header">
    
    <div class="d-flex align-items-center pt-3 pb-2">         

      <!-- logo -->
      <a href="https://www.niagaweb.co.id/blog/">
                     
              <img style="max-height:50px;" class="wows-logo-image" src="https://www.niagaweb.co.id/blog/wp-content/uploads/2021/03/Niagaweb-Logo-01.png" alt="Niagaweb Blog" />          
                </a>
      
      <!-- social header icons -->
      <div class="my-auto wows-header-right">
        <div class="wows-header-description my-0">
          <div class="header-social">
                      </div>
        </div>
      </div>  

    <!-- Toggle Menu Button -->
    <button class="navbar-toggler wows-header-nav-mobile-toggle ml-auto" type="button" data-toggle="collapse" data-target="#header-nav-content" aria-expanded="false" aria-label="Toggle navigation">
        <span class="fas"></span>
    </button>

    </div><!-- close d-flex -->

  </div><!-- close container -->

</div><!-- close wrap-logo-header -->
    

<div class="sticky-header ">
    <div class="container wows-header-nav-container">
        <div class="row">

            <nav class="navbar navbar-expand-lg navbar-light  wows-header-navbar col-12">

                <!-- Nav Content -->
                <div class="collapse navbar-collapse" id="header-nav-content">
                    <ul id="menu-menu-blog" class="wows-header-nav navbar-nav"><li id="menu-item-5" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home nav-item menu-item-5"><a href="https://www.niagaweb.co.id/blog/" class="nav-link">Beranda</a>
</li>
<li id="menu-item-2115" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children nav-item menu-item-2115 dropdown"><a href="https://www.niagaweb.co.id/blog/category/marketing/" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Digital Marketing</a>

<div class="dropdown-menu" aria-labelledby="Preview">
<a href="https://www.niagaweb.co.id/blog/category/marketing/seo-sem/" class="dropdown-item">SEO &amp; SEM</a>
<a href="https://www.niagaweb.co.id/blog/category/marketing/content-marketing/" class="dropdown-item">Content Marketing</a>
<a href="https://www.niagaweb.co.id/blog/category/marketing/email/" class="dropdown-item">Email</a>
<a href="https://www.niagaweb.co.id/blog/category/marketing/media-sosial/" class="dropdown-item">Media Sosial</a>
</div>
</li>
<li id="menu-item-2116" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children nav-item menu-item-2116 dropdown"><a href="https://www.niagaweb.co.id/blog/category/web-development/" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Web Development &amp; Design</a>

<div class="dropdown-menu" aria-labelledby="Preview">
<a href="https://www.niagaweb.co.id/blog/category/web-development/website-blog/" class="dropdown-item">Website &amp; Blog</a>
<a href="https://www.niagaweb.co.id/blog/category/web-development/design/" class="dropdown-item">Inspirasi Design</a>
</div>
</li>
<li id="menu-item-2117" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children nav-item menu-item-2117 dropdown"><a href="https://www.niagaweb.co.id/blog/category/bisnis/" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Insight Bisnis</a>

<div class="dropdown-menu" aria-labelledby="Preview">
<a href="https://www.niagaweb.co.id/blog/category/bisnis/bisnis-online/" class="dropdown-item">Bisnis Online</a>
<a href="https://www.niagaweb.co.id/blog/category/bisnis/stories/" class="dropdown-item">User Stories</a>
</div>
</li>
</ul>
                <span class="search search-wpb ml-auto"><a class="search-icon"><i class="fas fa-search"></i></a>
               
                </span>

                </div>

            </nav>
        </div>
    </div>
   
            <div class="progress-container">
            <div class="progress-bar" id="myBar"></div>
        </div>
      
    <div class="wpbsearchform container">
        <form role="search" method="get" class="search-form form py-3" action="https://www.niagaweb.co.id/blog">
  <div class="input-group">      
  <input type="search" class="search-field form-control" placeholder="Search here..." value="" name="s" title="Search for:">
  <span class="input-group-btn">
    <button class="btn btn-warning search-submit" type="submit" value="Search"><span class="fa fa-search"></span></button>
  </span>
  </div>
</form>    </div>

</div>


    
<!-- customizer style for cards -->
<style>
</style>



    <main class="container">
        

    <div class="wow-content-wrapper">

        <div class="row">
            
            <div class="col-md-8 wows-main mt-5 pt-5 text-ccenter mx-auto">

                <article id="post-" class="wows-page text-center">
                 
                    <h1 class="wows-page-title">404 No Page Found</h1>                  

                    <div class="wows-page-content col-md-6 mx-auto">

                        <p>It looks like nothing was found at this location. Maybe try a search?</p>

                        <form role="search" method="get" class="search-form form py-3" action="https://www.niagaweb.co.id/blog">
  <div class="input-group">      
  <input type="search" class="search-field form-control" placeholder="Search here..." value="" name="s" title="Search for:">
  <span class="input-group-btn">
    <button class="btn btn-warning search-submit" type="submit" value="Search"><span class="fa fa-search"></span></button>
  </span>
  </div>
</form>
                    </div>

                </article>
            </div>

        </div>
    </div>

</main><!-- close container, opened in header -->

        
    <div class="container mx-auto text-center mt-4 mb-4">
        <a href="https://www.niagaweb.co.id/blog/">
                       
                <img style="max-height:50px;" class="wows-logo-image" src="https://www.niagaweb.co.id/blog/wp-content/uploads/2021/03/Niagaweb-Logo-01.png" alt="Niagaweb Blog" />            
                    </a>
    </div>


<div class="container mt-4 mb-4">
    <div class="row justify-content-center">
            <div class="wows-footer-sidebar col-md-6">
            <li id="block-2" class="widget wows-widget wows-widget-footer widget_block widget_text">
<p class="has-text-align-center">Copyright © 2013-2021 Niagaweb | PT. Web Media Technology Indonesia</p>
</li>        </div>
    </div></div>
        
        
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KPZGF6S"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<script type="45aae500312a0fa76fca214f-text/javascript" id='edd-ajax-js-extra'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/www.niagaweb.co.id\/blog\/wp-admin\/admin-ajax.php","position_in_cart":"-1","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"","redirect_to_checkout":"0","checkout_page":"","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.11.5' id='edd-ajax-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/themes/medley/assets/js/bootstrap4x/popper.min.js?ver=1.0.1' id='js-bootstrap-popper-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/themes/medley/assets/js/bootstrap4x/bootstrap.min.js?ver=1.0.1' id='js-bootstrap-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/themes/medley/assets/js/theme.js?ver=1.0.1' id='js-theme-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/plugins/wp-claps-applause/js/js.cookie.js?ver=2.1.1' id='jquery-cookie-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" id='wp-claps-applause-js-extra'>
/* <![CDATA[ */
var clapsapplause = {"ajax_url":"https:\/\/www.niagaweb.co.id\/blog\/wp-admin\/admin-ajax.php","lovedText":"","loveText":""};
/* ]]> */
</script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-content/plugins/wp-claps-applause/js/claps-applause.js?ver=1.0.0' id='wp-claps-applause-js'></script>
<script type="45aae500312a0fa76fca214f-text/javascript" src='https://www.niagaweb.co.id/blog/wp-includes/js/wp-embed.min.js?ver=5.8.1' id='wp-embed-js'></script>

    <script src="/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="45aae500312a0fa76fca214f-|49" defer=""></script></body>
</html>
<!--
Performance optimized by W3 Total Cache. Learn more: https://www.boldgrid.com/w3-total-cache/


Served from: www.niagaweb.co.id @ 2022-04-09 04:32:25 by W3 Total Cache
-->